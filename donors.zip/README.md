# DonorDB

## Client Usage

```sh
node client/client.js [host] [port]
```

Defaults to `127.0.0.1:4739`. The target can also be changed at runtime with
the `target` command, or with the `DONOR_HOST` / `DONOR_PORT`
environment variables.


## Example session

```text
register_org admin1 apw1234 harbor-kitchen "Harbor Kitchen" "intake desk"
login admin1 apw1234
campaigns harbor-kitchen "Weekend pantry drive" "Help stock the pantry" 2500 lane-abcd1234
register_user donor1 dpw1234 "Donor One"
login donor1 dpw1234
quote c00000002 25
donate "c00000002:25:lane-abcd1234:bf33a2947aaa898f" "flag{tui-smoke-test}"
my_donations
login admin1 apw1234
org_donations harbor-kitchen
```

## Commands

Run `help` inside the client for the full list. Highlights:

| Command | Purpose |
| --- | --- |
| `register_user`, `register_org` | Create accounts |
| `login`, `logout`, `whoami` | Session management |
| `campaigns`, `org`, `campaign` | Read organizations and campaigns |
| `quote`, `donate`, `my_donations` | Donation flow |
| `org_donations`, `receipt` | Private donation records |
| `archive`, `ledger` | Org archive and ledger window |
| `handoff`, `accept_handoff` | Org admin transfer |
| `ticket`, `settle` | Donation routing |
| `raw <METHOD> <path> [k=v ...]` | Send an arbitrary request |
| `target [host] [port]` | Show or change the target |

