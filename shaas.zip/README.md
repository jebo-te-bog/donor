# ShaaS - Shell as a Service

What could possibly go wrong giving anyont that asks shell access? Sandboxes are safe, right?

## Tips

`radare2` is installed and configured locally.  If you've never done binary analysis in a CLI before,
here is a path to get you started:

Radare2 is a command-line reverse engineering tool that supports a variaety of plugins.

To open a binary in radare2, run `r2 -A <binary_path>`

This will open the r2 prompt, where you can issue commands to expore the binary.

To print the decompilation of the binary's main function, enter `pdg @ main` at the r2 prompt.
